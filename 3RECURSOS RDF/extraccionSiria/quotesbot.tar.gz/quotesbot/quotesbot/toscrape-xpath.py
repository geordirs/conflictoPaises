# coding=utf-8
from scrapy.item import Field
from scrapy.item import Item
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from scrapy.loader import ItemLoader
from scrapy.loader.processors import MapCompose



class RoomItem(Item):
	nombre = Field()
	tipo_ciudadano = Field()
	sexo = Field()
	provincia_muerte = Field()
	lugar_nacimiento = Field()
	fecha_muerte = Field()
	causa_muerte = Field()
	grupo_causante = Field()

class RoomCrawler(CrawlSpider):
	name = "martyrs-crawler"
	start_urls=['http://www.vdc-sy.info/index.php/en/martyrs/1/c29ydGJ5PWEua2lsbGVkX2RhdGV8c29ydGRpcj1ERVNDfGFwcHJvdmVkPXZpc2libGV8ZXh0cmFkaXNwbGF5PTB8']
	allowed_domains = ['vdc-sy.info'] #que dominios tiene permitido visitar

	rules ={
		Rule(LinkExtractor(allow=r'/index.php/en/details/martyrs'), callback = 'parse_items'), #acceder a cada item #crawling vertical
	}
	
	def parse_items(self, response):
		item= ItemLoader(RoomItem(),response)
		item.add_xpath('nombre', './/td/a/text()'),
		item.add_xpath('tipo_ciudadano', './/td[2]/text()'),
		item.add_xpath('sexo', './/td[3]/text()'),
		item.add_xpath('provincia_muerte', './/td[4]/text()'),
		item.add_xpath('lugar_nacimiento', './/td[5]/text()'),
		item.add_xpath('fecha_muerte', './/td[6]/text()'),
		item.add_xpath('causa_muerte', './/td[7]/text()'),
		item.add_xpath('grupo_causante', './/td[8]/text()'),
		
		yield item.load_item()


